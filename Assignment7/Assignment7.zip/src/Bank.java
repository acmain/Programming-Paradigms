
public class Bank extends Sprite {

	public Bank(){
		super("bank.png");
		super.setX(300);
		super.setY(300);
	}

}
