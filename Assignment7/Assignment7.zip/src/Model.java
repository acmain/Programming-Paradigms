import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;


class Model
{
    private ArrayList<Sprite> cars = new ArrayList<Sprite>();
    
    Model() throws IOException {
		cars.add(new Bank());
    }
    
    public void add(int x, int y) {
    	int i = cars.size() % 2;
    	Car car;
    	
		if(i == 0)
			car = new CopCar();
		else
			car = new RobberCar();
    	
    	car.setX(x);
    	car.setY(y);
    	cars.add(car);
    }

    public void update(Graphics g) {
		for(int i = 0; i < cars.size(); i++) 
			cars.get(i).updateImage(g);
    }
    
    public void updateScene(int width, int height) {
    	for(int i = 0; i < cars.size(); i++) 
			cars.get(i).updateState(width, height);
    }
}
